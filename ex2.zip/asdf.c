a:
bus: b(5) 
tram: no connections
sprinter: no connections
rail: no connections
----------------------------------
b:
bus: c(10) d(10) 
tram: no connections
sprinter: no connections
rail: no connections
----------------------------------
c:
bus: a(4) d(7) 
tram: no connections
sprinter: no connections
rail: no connections
----------------------------------
d:
bus: c(5) 
tram: no connections
sprinter: no connections
rail: no connections
----------------------------------
e:
bus: f(9) 
tram: no connections
sprinter: no connections
rail: no connections
----------------------------------
f:
bus: no connections
tram: no connections
sprinter: no connections
rail: no connections
----------------------------------
